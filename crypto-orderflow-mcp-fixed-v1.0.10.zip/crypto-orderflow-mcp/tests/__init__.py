"""Test suite for Crypto Orderflow MCP Server."""
