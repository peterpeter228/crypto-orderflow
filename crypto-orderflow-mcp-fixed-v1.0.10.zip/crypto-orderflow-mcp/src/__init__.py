"""Crypto Orderflow MCP Server - Market Data & Orderflow Indicators for Binance USD-M Futures."""

__version__ = "1.0.10"
